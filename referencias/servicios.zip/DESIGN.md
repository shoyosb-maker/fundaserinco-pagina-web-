---
name: Fundaserinco Glass Neon
colors:
  surface: '#111225'
  surface-dim: '#111225'
  surface-bright: '#37374d'
  surface-container-lowest: '#0b0c1f'
  surface-container-low: '#191a2d'
  surface-container: '#1d1e32'
  surface-container-high: '#27283d'
  surface-container-highest: '#323348'
  on-surface: '#e1e0fb'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e1e0fb'
  inverse-on-surface: '#2e2f43'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#dbb8ff'
  on-secondary: '#470083'
  secondary-container: '#6807ba'
  on-secondary-container: '#d0a6ff'
  tertiary: '#d8ffe5'
  on-tertiary: '#003822'
  tertiary-container: '#34f6a8'
  on-tertiary-container: '#006d46'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#efdbff'
  secondary-fixed-dim: '#dbb8ff'
  on-secondary-fixed: '#2b0052'
  on-secondary-fixed-variant: '#6600b7'
  tertiary-fixed: '#4dffb2'
  tertiary-fixed-dim: '#00e297'
  on-tertiary-fixed: '#002112'
  on-tertiary-fixed-variant: '#005234'
  background: '#111225'
  on-background: '#e1e0fb'
  surface-variant: '#323348'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes an ultra-professional, forward-looking visual language tailored for institutional credibility paired with high-tech innovation. Blending luminous glassmorphism with futuristic neon accents, the aesthetic bridges the seriousness of a foundational enterprise with the kinetic energy of an elite digital services powerhouse. 

The visual personality evokes deep trust, technological authority, and visionary execution. Interfaces avoid raw starkness by embedding multi-layered depth: midnight obsidian canvases provide infinite negative space while concentrated strokes of electric cyan, hyper-violet, and radiant emerald create focused focal anchors. Micro-surfaces shimmer with subtle rim lighting and translucent backdrops, delivering a tactile, polished feel that speaks to enterprise clients, partners, and institutional stakeholders.

## Colors

The palette is engineered around an immersive, deep-space dark mode anchored by `#0a0b1e`. 

- **Primary (`#00f0ff` - Electric Cyan):** Used for primary conversion triggers, focal highlights, active states, and leading glows.
- **Secondary (`#7928ca` - Deep Vivid Indigo/Violet):** Serves as an atmospheric counterbalance, gradient partner to cyan, and the backbone for secondary visual tiers and section framing.
- **Tertiary (`#00e599` - Hyper Emerald):** Reserved for metrics, success signals, status indicators, and energetic micro-badges.
- **Neutral Surface Palette:** Grounded in layered midnight tones (`#060714` for absolute background canvas, `#0e112c` for elevated glass panels, and `#1a1e42` for borders and resting contours).
- **Text & Contrast:** Primary text renders in high-legibility pure ice white (`#f4f6fd`), secondary metadata in muted periwinkle (`#94a3b8`), and tertiary hints in `#6272a4`.

Interactive elements rely on radiant gradients between electric cyan and hyper-violet, generating high-chroma illumination without fatiguing eye comfort over extended usage.

## Typography

The typographic hierarchy balances architectural structure with effortless readability on high-resolution displays.

- **Headlines & Display:** Set in **Plus Jakarta Sans**, offering geometric clarity, curved apexes, and modern punch. High weights (700-800) command attention in hero declarations and section headers, often paired with linear gradient fills spanning from ice-white to primary cyan.
- **Body & Numerical Readouts:** Set in **Inter** to ensure maximum scan-speed, crisp pixel rendering across varied displays, and optical stability in multi-line institutional text and dense metrics.
- **Badges & Micro-Labels:** Styled in uppercase or title-case `label-badge` with tracking expanded to `+0.06em`, generating an authoritative operational feel suitable for digital infrastructure and foundation initiatives.

## Layout & Spacing

A 12-column responsive fluid grid governs desktop and widescreen viewports, condensing gracefully into 6 columns on tablet breakpoints and 4 columns on mobile viewports.

- **Outer Margins:** Sized generously at `2.5rem` (`40px`) on desktop to maintain perimeter breathing room, tightening to `1.25rem` (`20px`) on mobile devices.
- **Content Max-Width:** Clamped at `1280px` for optimal eye-tracking and structural containment across ultra-wide monitors.
- **Section Stacking:** Vertical section intervals range from `5rem` (`80px`) to `7.5rem` (`120px`), allowing background light orbs and ambient gradients to diffuse cleanly without overlapping visual confusion.
- **Rhythm Principle:** Internal card padding scales strictly between `space-md` (compact cards, stat widgets) and `space-xl` (hero feature modules and interactive service showcases).

## Elevation & Depth

Visual hierarchy does not rely on traditional muddy drop-shadows; it is defined through translucent glassmorphism, multi-stop luminous outlines, and chromatic ambient glows.

1. **Base Layer (Canvas):** The foundation canvas (`#060714` to `#0a0b1e`) is interspersed with soft, radial neon blooms (`blur(120px)`) in cyan and deep violet to generate optical depth behind content blocks.
2. **Glass Level 1 (Resting Cards & Navigation):** `rgba(14, 17, 44, 0.65)` with a backdrop blur of `20px` to `24px`. Defined by a 1px composite border of `rgba(255, 255, 255, 0.08)` on the right and bottom, illuminated by `rgba(0, 240, 255, 0.25)` on the top-left edge.
3. **Glass Level 2 (Elevated & Active Containers):** `rgba(20, 24, 60, 0.8)` with backdrop blur of `32px`. Enhanced with an internal rim light (`inset 0 1px 1px 0 rgba(255, 255, 255, 0.2)`) and an exterior cyan-violet glow: `box-shadow: 0 12px 32px -8px rgba(0, 240, 255, 0.15), 0 0 20px 0 rgba(121, 40, 202, 0.2)`.
4. **Spotlight Highlights:** Micro-interactions induce dynamic glowing borders using gradient border-masks transitioning from `#00f0ff` to `#7928ca`, simulating illuminated edge-lit acrylic glass.

## Shapes

The design system employs a refined `Rounded` geometry (level 2). 

Standard interactive inputs, buttons, and badges leverage unified radii of `0.5rem` (`8px`) to `0.75rem` (`12px`), while display cards, metric panels, and modals adopt `rounded-lg` (`1rem` / `16px`) and `rounded-xl` (`1.5rem` / `24px`). Pill shapes (`9999px`) are reserved intentionally for micro status chips, section tag badges, and standalone pill-style CTAs. This balance guarantees sleek modernity without skewing overly toy-like or sterile.

## Components

### Buttons
- **Primary Action Button:** Gradient background transitioning from `#00f0ff` to `#7928ca` at 135deg. High-contrast ice-white text, bold weight (`label-lg`), pill or `0.75rem` roundedness. Accompanied by an outer bloom `0 0 24px rgba(0, 240, 255, 0.4)`. On hover, scale scales to `1.02` with amplified luminescent intensity.
- **Secondary Ghost Button:** Translucent backdrop `rgba(255, 255, 255, 0.04)` surrounded by a 1px border `rgba(255, 255, 255, 0.15)`. Text in `#f4f6fd`. On hover, border shifts to `#00f0ff` with an interior soft glow.

### Badge Chips & Tags
- Compact height (`26px` to `30px`), full pill geometry (`rounded-full`), padded with `0.75rem` horizontally.
- Semi-transparent tinted background (`rgba(0, 240, 255, 0.1)` or `rgba(121, 40, 202, 0.15)`), bordered with a 1px stroke of the matching accent color at 30% opacity.
- Prefixed with miniature glowing dots or illuminated micro-icons.

### Service & Feature Cards
- Constructed with frosted glass panels (`backdrop-filter: blur(24px)`).
- Features top-level 3D neon iconography resting inside glowing rounded squares.
- Interactive states: Cards slightly translate upward by `4px`, and the border transition intensifies into a dual-tone cyan-violet gradient with exterior ambient illumination.

### Metric & Foundation Impact Counters
- Designed with heavy numerical typographic weight (`Plus Jakarta Sans 800`) layered with gradient fills (`#ffffff` through `#00f0ff`).
- Accented with trending indicators (such as tertiary `#00e599` emerald micro-pills) showcasing institutional performance, volume, and verified results.

### Form Inputs & Text Fields
- Recessed midnight base (`rgba(8, 10, 26, 0.7)`), 1px subtle slate border (`#21284a`).
- Interior text rendered in `#f4f6fd` with `#6272a4` placeholder copy.
- Focus state triggers an immediate crisp `#00f0ff` border with an inset halo (`box-shadow: 0 0 0 3px rgba(0, 240, 255, 0.2)`).

### Lists & Accordions
- Framed within unified translucent glass enclosures. Rows separated by low-opacity gradient dividers (`linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.08), transparent)`).
- Hovering illuminates the active row with a gentle cyan ambient wash.